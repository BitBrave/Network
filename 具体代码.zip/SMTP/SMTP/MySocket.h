﻿#pragma once
#include <string>
#include <atlimage.h>
#include <vector>
using namespace std;
// CMySocket 命令目标

class CMySocket : public CAsyncSocket
{
public:
	CMySocket();
	virtual ~CMySocket();
	virtual void OnSend(int nErrorCode);
	virtual void OnReceive(int nErrorCode);
	UINT m_nLength;//消息长度
	char m_Buffer[524288];//消息内容，收到的邮件2  19cifang
	int m_count;//计算当前信息执行到第几步，即客户端与邮件服务器的交互程度
	bool m_state;//标记状态false代表send()运行，true代表receive运行
	//base64解码函数，对收到的文本进行解码
	CString Txt_DecodeBase64(CString inpt, int * len);	
	//显示邮件解析正文，即邮件的正文内容
	void ShowData();	
	//
	CString m_content_string;
	CImage m_image;//显示附件的图像
	//如果有图像则把图像显示出来
	void ShowImage(void);
	CString m_filename;			//附件名称
	//附件图像的base64解码算法
	void CMySocket::Image_DecodeBase64(CString dataFromPicStart, vector<char>& bytes);
	/*base64的算法很简单：它将字符流顺序放入一个 24 位的缓冲区，
	缺字符的地方补零。
	然后将缓冲区截断成为 4 个部分，
	高位在先，每个部分 6 位（6位二进制数可表示0~63）*/
};


